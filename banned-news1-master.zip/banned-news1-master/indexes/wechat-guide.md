#### 安卓系统用户

点击右上角 "..."，点击 "在浏览器中打开" ，收藏/添加书签/保存网址（各浏览器略有不同）

<img src='http://gfw-breaker.win/videos/nginx/1.png' width="300px"/>

#### 苹果系统用户

点击右上角 "..."，点击 "在Safari中打开" ，在Safari中点击底部中间图标，点击"添加书签"
